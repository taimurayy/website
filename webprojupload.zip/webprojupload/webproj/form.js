function readdata()
{
    var n=document.getElementById("fname").value;
    var e=document.getElementById("femail").value;
    var p=document.getElementById("fphone").value;
    var name=/^[A-Z]/;
    var i=0;
    
    if(!(name.test(n)))
    {
        alert("name should contain both captial and small letters");
        
    }
    else
    {
        i=i+1;
    }
    var email=/[w]*@[a-z]*.com/;
    if(!(email.test(e)))
    {
        alert("email should have proper format");
        
    }
    else
    {
        i=i+1;
    }
    var no=/[[0-9]{11}/;
    if(!(no.test(p)))
    {
        alert("no should have proper format");
        
    }
    else
    {
        i=i+1;
    }   


    if(i==3)
    {
        alert("form submit successfully");
    }
    
    
}