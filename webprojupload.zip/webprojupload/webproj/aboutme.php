<!doctype html>
<html lang="en">
  <head>
    <title>About me</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="aboutme.css">

    <script src="open.js"></script>
    <script src="aboutme.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <div class="container">


        <br>

        <div class="row">

            <div class="col-0">
                <div class="logo">
                <img src="goku.png" alt="">
                </div>
            </div>

            <div class="col-3">
                <div class="logoname">
                <h3>Taimur.</h3>
                </div>
            </div>

            <div class="col-2 offset-4 ml-auto">

                <div class="icons">
                    <a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a>
                    <a href="https://twitter.com/home" class="fa fa-twitter" target="_blank"></a>
                    <a href="https://www.instagram.com/taimurfazliqureshi/" class="fa fa-instagram" target="_blank"></a>
                    <a href="https://www.linkedin.com/in/taimur-fazli-80b173244/" class="fa fa-linkedin" target="_blank"></a>

                </div>

            </div>


        </div>

        


        <div class="row">


            <div class="col-12 ml-4">

                <div class="nav">
                <a href="" id="http://localhost:88/ok/webproj/index.php" onclick="read(id)">HOME</a>
                    <a href="" id="http://localhost:88/ok/webproj/aboutme.php" onclick="read(id)">ABOUT ME</a>
                    <a href="" id="http://localhost:88/ok/webproj/projects.php" onclick="read(id)">PROJECTS</a>
                    <a href="" id="http://localhost:88/ok/webproj/form.php" onclick="read(id)">CONTACT ME</a>
                </div>

            </div>

        </div>

        <br>
        <br>
        <div class="c">
        <div class="row">
            <div class="col-5">
                <h3 align="left">About me</h3>
            </div>

        </div>


        <div class="row">


            <div class="col-12">
            <div class="par">

                I am a person who is positive about every aspect of life. There are many things I like to do, to see, and to experience. I like to read, I like to write; I like to think, I like to dream; I like to talk, I like to listen. I like to see the sunrise in the morning, I like to see the moonlight at night; I like to feel the music flowing on my face, I like to smell the wind coming from the ocean. I like to look at the clouds in the sky with a blank mind, I like to do thought experiment when I cannot sleep in the middle of the night. I like flowers in spring, rain in summer, leaves in autumn, and snow in winter. I like to sleep early, I like to get up late; I like to be alone, I like to be surrounded by people. I like country’s peace, I like metropolis’ noise; I like the beautiful west lake in Hangzhou, I like the flat cornfield in Champaign. I like delicious food and comfortable shoes; I like good books and romantic movies. I like the land and the nature, I like people. And, I like to laugh.


            </div>
            </div>


        </div>


        



        </div>



        <br><br>
        <footer>

        <div class="row">

        
          <div class="col-6 offset-4">

          

               <div class="ficons">

                <a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a>
                <a href="https://twitter.com/home" class="fa fa-twitter" target="_blank"></a>
                <a href="https://www.instagram.com/taimurfazliqureshi/" class="fa fa-instagram" target="_blank"></a>
                <a href="https://www.linkedin.com/in/taimur-fazli-80b173244/" class="fa fa-linkedin" target="_blank"></a>
               </div>


               

        </div>

        </div>

        <div class="row">


          <div class="col-6 offset-4">

            <p class="copyright">TAIMUR© 2018</p>

          </div>


        </div>
         
      </footer>













    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>