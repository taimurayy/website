function read(id)
{
    window.open(id,"_blank");
}