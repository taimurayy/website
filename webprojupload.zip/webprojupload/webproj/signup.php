<?php
 

    $conn = mysqli_connect("localhost", "root", "", "USR");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }
      echo "Connected successfully";
  
    $name = $_POST['name'];
    $email = $_POST['email']; 
    $phone =$_POST['phone'];
    $password = $_POST['password'];




    $qr = "INSERT INTO details(name,email,phone,password) VALUES('$name','$email','$phone','$password')";

$res = mysqli_query($conn, $qr);
header("location:login.php");
     

  

?>