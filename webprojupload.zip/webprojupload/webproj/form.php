<!doctype html>
<html lang="en">
  <head>
    <title>form</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="form.css">
    <script src="form.js"></script>
    <script src="open.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      

   <div class="container">
    
    <br>


    <div class="row">

        <div class="col-0">
            <div class="logo">
            <img src="goku.png" alt="">
            </div>
        </div>

        <div class="col-3">
            <div class="logoname">
            <h3>Taimur.</h3>
            </div>
        </div>

        <div class="col-2 offset-4 ml-auto">

            <div class="icons">
                <a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a>
                <a href="https://twitter.com/home" class="fa fa-twitter" target="_blank"></a>
                <a href="https://www.instagram.com/taimurfazliqureshi/" class="fa fa-instagram" target="_blank"></a>
                <a href="https://www.linkedin.com/in/taimur-fazli-80b173244/" class="fa fa-linkedin" target="_blank"></a>

            </div>

        </div>


    </div>

    


    <div class="row">


        <div class="col-12 ml-4">

            <div class="nav">
            <a href="" id="http://localhost:88/ok/webproj/index.php" onclick="read(id)">HOME</a>
                    <a href="" id="http://localhost:88/ok/webproj/aboutme.php" onclick="read(id)">ABOUT ME</a>
                    <a href="" id="http://localhost:88/ok/webproj/projects.php" onclick="read(id)">PROJECTS</a>
                    <a href="" id="http://localhost:88/ok/webproj/form.php" onclick="read(id)">CONTACT ME</a>
            </div>

        </div>

    </div>

    <br>
   


    <div class="row">

        <div class="col-3">
            <div class="heading">
            <h3>CONTACT ME</h3>
            </div>
        </div>

    </div>
    

    <br>
    <br>
    <div class="row">


        <div class="col-8">


           <div class="form">
            <form action="" method="post" >

                <label for="">NAME: &nbsp</label>
                <input id="fname" name='n' type="name">
                <br>
                <label for="">EMAIL: &nbsp</label>
                <input id="femail" name='e' type="text">
                <br>
                <label for="">PHONE:</label>
                <input id="fphone" name='p' type="text">
                <br>
                <label for="">ROLE: &nbsp</label>
                <input id="fstudent" value="student" type="radio">
                <label for="">Student</label>
                <input id="fteacher" value="teacher" type="radio">
                <label for="">Teacher</label>
                <br>
                <label for="">SELECT CITY: </label>
                <select name="" id="scity">
                    <option value="">lahore</option>
                    <option value="">islamabad</option>
                </select>
                <br>
                <label for="">MESSAGE</label>
                <br>
                <input id="fmsg" type="message" name='m' style="height:250px; width:400px;">
                <br>
                <br>
                <button onclick="readdata()">Submit</button>
              


            </form>
            </div>

            <?php


                session_start();
                $_SESSION['count'] = 1;
                $conn = mysqli_connect("localhost", "root", "", "USR");
                $name = $_POST['n'];
                $email = $_POST['e'];
                $phone = $_POST['p'];
                $msg = $_POST['m'];
            if ($_SESSION['count'] < 2) {


                $qry = "INSERT INTO contact_us(name,email,phone,messge) VALUES('$name','$email','$phone','$msg')";
                $_SESSION['count'] += 1;
                if ($conn->query($qry) === TRUE) {


                } else {
                    echo "Error: " . $qry . "<br>" . $conn->error;
                }
            }
          else
          {
                echo "<script>alert('CANT ENTER FORM NORE THEN 2')</script>";
          }


            ?>
        </div>


        <div class="col-4">

            <address>
                Written by <a href="mailto:webmaster@example.com">Taimur</a>.<br>
                Visit me at:<br>
                Iqbal town, Lahore<br>
                Pakistan
                </address>

                <div class="map">


                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13604.856715602938!2d74.25314605000001!3d31.518276949999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2s!4v1669989101577!5m2!1sen!2s" width="300" height="300" style="border: 1px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                </div>

              
            </div>





    </div>



    
    <br><br>
    <footer>

    <div class="row">

    
      <div class="col-6 offset-4">

      

           <div class="ficons">

            <a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a>
            <a href="https://twitter.com/home" class="fa fa-twitter" target="_blank"></a>
            <a href="https://www.instagram.com/taimurfazliqureshi/" class="fa fa-instagram" target="_blank"></a>
            <a href="https://www.linkedin.com/in/taimur-fazli-80b173244/" class="fa fa-linkedin" target="_blank"></a>
           </div>


           

    </div>

    </div>

    <div class="row">


      <div class="col-6 offset-4">

        <p class="copyright">TAIMUR© 2018</p>

      </div>


    </div>
     
  </footer>







   </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>