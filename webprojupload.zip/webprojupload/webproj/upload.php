<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>upload image</title>
</head>
<body>
        
    
<form method="post">
  <input type="file" id="myFile" name="filename">
  <br>
  <br>
  <label for="">ENTER DESCRIPTION: </label>
  <input type="text" id="des" name="des">
    <br>
    <br>
    <label for="">ENTER PRICE: </label>
  <input type="number" id="p" name="p">
    <br>
    <br>
  <input type="submit" onclick="getback()">
</form>


<?php

$imgid = $_POST['filename'];
$description = $_POST['des'];
$price = $_POST['p'];


    $conn = mysqli_connect("localhost", "root", "", "USR");

   

    $qr = "INSERT INTO project(img_id,details,price) VALUES('$imgid','$description','$price')";
      
    if ($conn->query($qr) === TRUE) {

      
      } else {
        echo "Error: " . $qr . "<br>" . $conn->error;
      }




?>

<script>
    
    function getback()
    {
        window.open("http://localhost:88/ok/webproj/projects.php","_blank");
    }

</script>






</table>
</body>
</html>

