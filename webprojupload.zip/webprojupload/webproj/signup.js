function insert()
{

   
    
    var name=document.getElementById("name").value;
    var email=document.getElementById("email").value;
    var phone=document.getElementById("phone").value;
    var password=document.getElementById("password").value;
    var cpassword=document.getElementById("cp").value;
    if(name.length==0)
    {
       
        alert("NAME CANNOT BE EMPTY");
        
        
    }
    else if(email.length==0)
    {
        
        alert("email CANNOT BE EMPTY");

       
        
    }
    else if(phone.length==0)
    {
        
        alert("phone CANNOT BE EMPTY");
       
       
    }
    else if(password.length==0)
    {
        
        alert("password CANNOT BE EMPTY");
        
        
    }    
    else if(cpassword.length==0)
    {
       
        alert("CONFIRM YOUR PASSWORD CANNOT BE EMPTY");
        
    } 
    else if(cpassword!=password)
    {
        
        alert("plus confirm your password");
       
    }
  
    else
    {
        var req=new XMLHttpRequest();
    
        req.open("POST","signup.php",true);
        req.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        req.send("name="+name+"&email="+email+"&phone="+phone+"&password="+password);
        alert("you are registered");
    }
     
   
  
}