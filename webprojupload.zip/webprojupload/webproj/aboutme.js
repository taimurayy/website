// var images = [];

// images[0] = ["a-funso-crop.jpg"];
// images[1] = ["red.jpg"];
// images[2] = ["place.jpg"];
// var index = 0;

// function change() {
//   document.getElementById("mainPhoto").src = images[index];
//   if (index == 2) {
//     index = 0;
//   } else {
//     index++;
//   }

//   setTimeout(change, 1);
// }

// window.onload = change();