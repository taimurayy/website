<?php
        session_start();

        $email = $_POST['e'];
        $password = $_POST['p'];

        $conn = mysqli_connect("localhost", "root", "", "USR");
        $qr = "select * from details";
        $res = mysqli_query($conn, $qr);
       
          $flag =0;
        
        $i = 0;
        
        while($data=mysqli_fetch_array($res))
        {
            if($data[1]==$email)
            {
                if($data[3]==$password)
                {
                    $flag = 1;
                    break;
                }
            }
          $flag = 0;
            
        }
        
        if($flag==1)
        {
            $_SESSION['username'] = $data[0];
            header('location:index.php');
        } else {
  header('location:login.php');
}
        


      ?>