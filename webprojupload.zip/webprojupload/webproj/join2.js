function show()
{

 
var x=window.localStorage.getItem("strg");
var y=window.localStorage.getItem("strg1");
document.getElementById("pimgid").src=x;
document.getElementById("pdet").innerHTML=y;

}