<!doctype html>
<html lang="en">
  <head>
    <title>PROJECTS</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="project.css">
    
    <script src="open.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      

    <div class="container">

        <br>

        <div class="row">

            <div class="col-0">
                <div class="logo">
                <img src="goku.png" alt="">
                </div>
            </div>

            <div class="col-3">
                <div class="logoname">
                <h3>Taimur.</h3>
                </div>
            </div>

            <div class="col-2 offset-4 ml-auto">

                <div class="icons">
                    <a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a>
                    <a href="https://twitter.com/home" class="fa fa-twitter" target="_blank"></a>
                    <a href="https://www.instagram.com/taimurfazliqureshi/" class="fa fa-instagram" target="_blank"></a>
                    <a href="https://www.linkedin.com/in/taimur-fazli-80b173244/" class="fa fa-linkedin" target="_blank"></a>

                </div>

            </div>


        </div>

        


        <div class="row">


            <div class="col-12 ml-4">

                <div class="nav">
                <a href="" id="http://localhost:88/ok/webproj/index.php" onclick="read(id)">HOME</a>
                    <a href="" id="http://localhost:88/ok/webproj/aboutme.php" onclick="read(id)">ABOUT ME</a>
                    <a href="" id="http://localhost:88/ok/webproj/projects.php" onclick="read(id)">PROJECTS</a>
                    <a href="" id="http://localhost:88/ok/webproj/form.php" onclick="read(id)">CONTACT ME</a>
                    <?php
                    session_start();
                    if ($_SESSION['username'] == 'admin'||$_SESSION['username'] == 'ADMIN') {
                        echo "<a href='http://localhost:88/ok/webproj/upload.php' target='blank'>CLICK TO ADD IMAGE</a>";
                    }
                    ?>
                    
                </div>

            </div>

        </div>

        <br>
        <br>
        <div class="c">
        <div class="row">
            <div class="col-5 m-auto">
                <h3 align="center">C++ Projects</h3>
            </div>

        </div>
        </div>

        <br>

        <div class="cproj">

            <div class="row">
                <br>

                <div class="col-4 offset-1">
                    <img src="redblack.png" onclick="details('redblack.png','In computer science, a red-black tree is a kind of self-balancing binary search tree. Each node stores an extra bit representing color, used to ensure that the tree remains balanced during insertions and deletions.')" alt="">
                    <h6>RED BLACK TREE</h6>
                    <h6>Click on the image for details</h6>
                </div>
                

            </div>

        </div>

    <br>

        <div class="header">
        <div class="row">
            <div class="col-7 m-auto">
                <h3>Some Projects in made Blender 3d and Unity</h3>
            </div>
        </div>
        </div>
       
        <br>

        <div class="projects">
            <br>
            <div class="row">
                <div class="col-4 offset-1">
                <img src="a-funso-crop.jpg" onclick="details('a-funso-crop.jpg','Princess Ira Giselle Is a fictional African princess with gold gifted powers. Her face painting is inspired by Nigerian traditional face decorations. Her crown adorned with crystals, crosses and chains incorporates several elements from different cultural designs from all over the world to portray unity.')" alt="">
                <h6>Princess Era</h6>
                <h6>click on the img for more details</h6>
                </div>

                <div class="col-4 offset-1">
                    <img id="redpic" src="red.jpg" onclick="details('red.jpg','Had the pleasure of recreating some concept art in 3D. Original concept by Juhani Jokinen.')" alt="">
                    <h6>Red house</h6>
                    <h6>Click on the img for more details</h6>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-4 offset-1">
                    <img src="table.jpg" onclick="details('table.jpg','This is the first model that I upload to The Rookies and its a cartoon modeling done in a course by Albert Valls from domestika.')" alt="">
                    <h6>Classic table</h6>
                    <h6>Click on the image for more details</h6>
                </div>
                <div class="col-4 offset-1">
                    <img src="knife.jpg" onclick="details('knife.jpg','Design based on BUCK KNIVES My second project for the rookie weekly drills, in this project I really focused on making a practical game ready asset and improve my texturing skills. 10994 Tris')" alt="">
                    <h6>Cutter Knife</h6>
                    <h6>click on the image for more details</h6>
                </div>
            </div>
            <br>
            <div class="row">

                <div class="col-4 offset-1">
                    <img src="men.jpg" onclick="details('men.jpg','Heres a 3D character made with the beautiful OC of Ye Zhang : artstation/yezhang Blockin and Highpoly in Zbrush Topology, UV done with Blender Textured with Substance Painter and Idle done with Maya. UV Set : Human : 4096x4096 Dog : 4096x4096 Sword : 2048x2048 Thanks to Artside School and my mates for the feedback!')" alt="">
                    <h6>3d character</h6>
                    <h6>click on the image for more details</h6>
                </div>
                <div class="col-4 offset-1">
                    <img src="place.jpg" onclick="details('place.jpg','Graduation project made for the Concept Art specialised cursus at New3dge School')" alt="">
                    <h6>Graduation place</h6>
                    <h6>Click on the image for more details</h6>
                </div>

            </div>
           


            <script>

            function details(x,y)
            {
            
                
                localStorage.setItem("strg1",y);
                localStorage.setItem("strg",x);
                
                window.open("http://localhost:88/ok/webproj/projdet.php","_blank");
            

            }


            </script>
            

            <?php
        
                $conn = mysqli_connect("localhost", "root", "", "USR");
                $qr = "select * from project";

                $res=mysqli_query($conn,$qr);
                while($data=mysqli_fetch_array($res))
                {

                echo "<div class='row'>

                  
                    <div class='col-4 offset-1'>
                        <img src='$data[0]' name='$data[1]' onclick='details(src,name)' alt=''>
                        <h6>$data[1]</h6>
                        <h6>Click on the image for more details</h6>
                        ";
                
                if ($_SESSION['username'] == 'admin'||$_SESSION['username'] == 'ADMIN') {
                    echo "<button id='$data[0]' onclick='update(id)'>update image</button><br>";
                    echo "<div id='input1'></div>";
                    echo "<button  id='$data[0]' onclick='display(id)'>delete image</button>";
                }
                echo "</div></div>";
                }


                    
        
        
            ?>
            

            <br>
        
        </div>
       
        <script>

                function update(id)
                {
                    var str=id;
                    var ok="<form method='post'><input type='text' name='pic' value="+str+"><input type='text' name='desc' placeholder='new description'><input type='number' name='price' placeholder='new price'><input type='submit'></form>";
                    document.getElementById('input1').innerHTML=ok;
                    

                }
            function display(id) 
            {
            
                var req = new XMLHttpRequest();
                req.open("POST", "delete.php", true);
                req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                req.send("id=" + id);
                window.open("projects.php");
            }
            </script>


       
               
            


        </script>
       
            <?php

            $n = $_POST['pic'];
            $d = $_POST['desc'];
            $p = $_POST['price'];
            
            $conn = mysqli_connect("localhost", "root", "", "USR");
            $qr = "update project set details='$d', price='$p' where img_id='$n'";
            $res=mysqli_query($conn, $qr);
            
            
            ?>

        <br><br>
        <footer>

        <div class="row">

        
          <div class="col-6 offset-4">

          

               <div class="ficons">

                <a href="https://www.facebook.com/" class="fa fa-facebook" target="_blank"></a>
                <a href="https://twitter.com/home" class="fa fa-twitter" target="_blank"></a>
                <a href="https://www.instagram.com/taimurfazliqureshi/" class="fa fa-instagram" target="_blank"></a>
                <a href="https://www.linkedin.com/in/taimur-fazli-80b173244/" class="fa fa-linkedin" target="_blank"></a>
               </div>


               

        </div>

        </div>

        <div class="row">


          <div class="col-6 offset-4">

            <p class="copyright">TAIMUR© 2018</p>

          </div>


        </div>
         
      </footer>



    </div>







    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>