<?php


             $conn = mysqli_connect("localhost", "root", "", "USR");
             $id = $_POST['id'];
             $qr = "delete from project where img_id='$id'";
             $res=mysqli_query($conn,$qr);
?>