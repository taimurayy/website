function details(x,y)
{
   
    
    localStorage.setItem("strg1",y);
    localStorage.setItem("strg",x);
    
    window.open("http://localhost:88/ok/webproj/projdet.php","_blank");
  

}
